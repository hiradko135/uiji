# PrimeMusic-Lavalink
LAVALINK BOT MADE BY SHIVA.

Fork the Repositry and add your bot token. Must turn on intents and run the code.
Use /play to start playing the songs.

# Supports
- YouTube
- SoundCloud
- Spotify

Links / Text / Playlists
 
